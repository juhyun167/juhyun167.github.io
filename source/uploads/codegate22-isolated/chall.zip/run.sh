#!/bin/bash

cd /home/ctf/
timeout 15 ./isolated