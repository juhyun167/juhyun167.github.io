#!/bin/bash

cd /home/ctf/
timeout 60 qemu-arm-static -L /usr/arm-linux-gnueabi ./app
