#!/bin/bash

cd /home/ctf/
timeout 30 ./trust_code
