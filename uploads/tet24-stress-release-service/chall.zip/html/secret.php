<?php 

// Veryyyyyy Secretttttttttttt !!!!!!!!!!!!!!!!!
$FL4ggggggggggg = "TetCTF{__F33ls_G0od_M4nnnnnnnnnN_(^_^)/_}";

?>
